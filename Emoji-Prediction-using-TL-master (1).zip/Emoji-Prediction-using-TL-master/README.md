# Emoji Prediction using Transfer Learning
> This is Machine Learning Project in which we use the Concepts of Transfer Learning and LSTM to make a ML model
that can be used to predict emojis.